# housing_society_management
A web application aims to digitise the activities of the society. Application is created by keeping in mind the target user types hence member and admin logins provided. The admin can put the notice, meeting details and see all complaints,queries and join committee requests. The members can pay their payment on the provided paytm account. Anyone can file a complain, ask their query and if want can place join committee requests and notices and meeting docs are also available.
Only the docs names are stored on mysql not the docs to avoid storage issues.

The bootstrap template is used and modified for creating the web application.

For enriching the application with the features and make it usable for any society following are essential features for improvements :
1> User input validation is a must to-do
2> We can have session login for security purposes and logout also 
3> Payment details can be provided for admin
4> Of course, at few places better animation and font selection can be done.
