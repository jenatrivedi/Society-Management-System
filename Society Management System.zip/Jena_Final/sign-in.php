<?php
  $email = $_POST['email'];
  $password = $_POST['password'];
  //DATA CONNECTED
  $conn = new mysqli('localhost','root','','request2'); 
  if($conn->connect_error){
	  die('connection failed'.$conn->connect_error);
  }
  else{
	  $stmt = $conn->prepare("insert into registration7(email,password) values(?,?)");
	  $stmt->bind_param("ss",$email,$password);
	  $stmt->execute();
	  echo "registration successfully";
	  $stmt->close();
	  $conn->close();
  }
?>