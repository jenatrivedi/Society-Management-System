<?php
  $name = $_POST['name'];
  $email = $_POST['email'];
  $contact = $_POST['contact'];
  $message = $_POST['message'];
  //DATA CONNECTED
  $conn = new mysqli('localhost','root','','request2'); 
  if($conn->connect_error){
	  die('connection failed' .$conn->connect_error);
  }
  else{
	  $stmt = $conn->prepare("insert into registration9(name,email,contact,message) values(?,?,?,?)");
	  $stmt->bind_param("ssis",$name,$email,$contact,$message);
	  $stmt->execute();
	  echo "registration successfully";
	  $stmt->close();
	  $conn->close();
  }
?>