<?php
  $name = $_POST['name'];
  $email = $_POST['email'];
  $contact = $_POST['contact'];
  $flat_details = $_POST['flat_details'];
  $complaint_type = $_POST['complaint_type'];
  $supporting_documents = $_POST['supporting_documents'];
  //DATA CONNECTED
  $conn = new mysqli('localhost','root','','request2'); 
  if($conn->connect_error){
	  die('connection failed' .$conn->connect_error);
  }
  else{
	  $stmt = $conn->prepare("insert into registration8(name,email,contact,flat_details,complaint_type,supporting_documents) values(?,?,?,?,?,?)");
	  $stmt->bind_param("ssisss",$name,$email,$contact,$flat_details,$complaint_type,$supporting_documents);
	  $stmt->execute();
	  echo "registration successfully";
	  $stmt->close();
	  $conn->close();
  }
?>